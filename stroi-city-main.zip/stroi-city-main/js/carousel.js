$('#carousel-1').owlCarousel({
	items: 1,
	loop: true,
	dots: true,
	autoplay: true,
	smartSpeed: 600
});